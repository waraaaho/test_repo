

def getSchema(owner, model, db):
    
    #import time
    #start = time.time()
    
    docs = db["customer_model_table"].find({'owner':owner})
    for doc in docs:
        models = (doc["models"])
    
    for model_item in models:
        if model_item['model_name']== model:
            schema_is_in = (model_item['ID'])
        
    docs = db[schema_is_in].find({"owner":owner, "schema":"yes" })
    for doc in docs:
        schema = doc
        
        #end = time.time()
        #print("getSchema time:"+str(end-start))
        
        return schema