import json
import pymongo
import boto3
import pandas as pd
from datetime import datetime
from getSchema import getSchema
from getEncodedData import getEncodedData, take_info_from_schema#, getModelVersions
from feature_selection import feature_selection
from ENV_definitions import ENV_db_client_URL,ENV_db_database,ENV_data_loaded_to_pipelineSNS

db_client = pymongo.MongoClient(ENV_db_client_URL)
db = db_client[ENV_db_database]

def lambda_handler(event, context): 
    print("FunctionFeatureSelection Received event: " + json.dumps(event, indent=2))
    message = event['Records'][0]['Sns']['Message']
    print("From SNS:: " + message)
    messageJSON = json.loads(message) 
    model_id = messageJSON['model'] # NLmodel_xx
    
    
    # objId = messageJSON['_id']
    #str_time_stamp = messageJSON['time_stamp'] ###
    owner = messageJSON['owner']
    featureSelection = messageJSON['featureSelection']
    # name_for_model,msg = encoder_column(ObjectId(objId),model_id,db) # name_for_model ==NLmodel_xx_for_model
    model_name = db[model_id].find_one()['modelname']
    
    print(owner)
    print(model_name)
    
    
    data_encoded = getEncodedData(owner, model_name, db) #all data received
    print(data_encoded)
    print(type(data_encoded))
    full_data_schema = getSchema(owner, model_name, db)
    print(full_data_schema)
    print(type(full_data_schema))

    data_input = pd.json_normalize(data_encoded['record'])
    selected_features = feature_selection(data_input)
    print(selected_features)
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
